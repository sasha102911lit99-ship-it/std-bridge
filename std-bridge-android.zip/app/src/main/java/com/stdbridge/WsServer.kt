package com.stdbridge

import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.DefaultSSLWebSocketServerFactory
import org.java_websocket.server.WebSocketServer
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import javax.net.ssl.SSLContext

/**
 * Защищённый WebSocket-сервер (wss). Binary-сообщения — JPEG-кадры,
 * текстовые — служебный JSON. Авторизация — токен в query (?token=).
 */
class WsServer(
    port: Int,
    private val token: String,
    sslCtx: SSLContext,
    private val frameW: Int,
    private val frameH: Int,
    private val frameFps: Int
) : WebSocketServer(InetSocketAddress(port)) {

    init {
        webSocketFactory = DefaultSSLWebSocketServerFactory(sslCtx)
        connectionLostTimeout = 30
        isReuseAddr = true
    }

    override fun onOpen(conn: WebSocket, handshake: ClientHandshake) {        val desc = handshake.resourceDescriptor // "/?token=xxxx"
        val query = desc.substringAfter("?", "")
        val got = query.split("&")
            .firstOrNull { it.startsWith("token=") }
            ?.substringAfter("=")
        if (token.isNotBlank() && got != token) {
            conn.close(4401, "bad token")
            return
        }
        conn.send(
            """{"type":"hello","w":$frameW,"h":$frameH,"fps":$frameFps}"""
        )
    }

    override fun onClose(conn: WebSocket, code: Int, reason: String, remote: Boolean) { }

    override fun onMessage(conn: WebSocket, message: String) {
        if (message.contains("\"ping\"")) {
            conn.send("""{"type":"pong","t":${System.currentTimeMillis()}}""")
        }
        try { onText?.invoke(message, conn) } catch (e: Exception) { }
    }

    /** Обратный вызов текстовых команд (touch/arm/info). Назначает ScreenService. */
    var onText: ((String, WebSocket) -> Unit)? = null

    override fun onMessage(conn: WebSocket, message: ByteBuffer) { }

    override fun onError(conn: WebSocket?, ex: Exception) { }

    override fun onStart() { }

    /** Рассылка кадра всем авторизованным клиентам. */
    fun broadcastFrame(jpeg: ByteArray) {
        if (jpeg.isEmpty()) return
        try {
            broadcast(ByteBuffer.wrap(jpeg))
        } catch (e: Exception) {
            // Клиент мог отвалиться между проверкой и отправкой — пропускаем кадр.
        }
    }
}
