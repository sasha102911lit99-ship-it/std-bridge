package com.stdbridge

import android.annotation.SuppressLint
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.asn1.x509.Extension
import org.bouncycastle.asn1.x509.GeneralName
import org.bouncycastle.asn1.x509.GeneralNames
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.SecureRandom
import java.util.Calendar
import java.util.Date
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory

/**
 * Самоподписанный сертификат для wss. Хранится в приватном файле приложения,
 * перевыпускается кнопкой из README (удали файл bridge.p12 — создастся новый).
 * SAN покрывают localhost/127.0.0.1 (adb forward) и текущий IP Wi-Fi.
 */
object CertUtil {
    private const val FILE = "bridge.p12"
    private const val ALIAS = "bridge"
    private val PWD = "stdbridge".toCharArray()

    fun getOrCreateSSLContext(dir: File): SSLContext {
        val f = File(dir, FILE)
        val ks: KeyStore = if (f.exists()) load(f) else create(f)
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, PWD)
        val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        tmf.init(ks)
        return SSLContext.getInstance("TLS").also { it.init(kmf.keyManagers, tmf.trustManagers, SecureRandom()) }
    }

    private fun load(f: File): KeyStore =
        KeyStore.getInstance("PKCS12").also { f.inputStream().use { ks -> it.load(ks, PWD) } }

    @SuppressLint("DefaultLocale")
    private fun create(f: File): KeyStore {
        val gen = KeyPairGenerator.getInstance("RSA")
        gen.initialize(2048, SecureRandom())
        val kp = gen.generateKeyPair()

        val now = Date()
        val exp = Calendar.getInstance().apply { time = now; add(Calendar.YEAR, 5) }.time
        val name = X500Name("CN=STD-Bridge")
        val builder = JcaX509v3CertificateBuilder(
            name, BigInteger(64, SecureRandom()), now, exp, name, kp.public
        )
        val sans = mutableListOf(
            GeneralName(GeneralName.dNSName, "localhost"),
            GeneralName(GeneralName.dNSName, "std-bridge"),
            GeneralName(GeneralName.iPAddress, "127.0.0.1")
        )
        lanIp()?.let { sans.add(GeneralName(GeneralName.iPAddress, it)) }
        builder.addExtension(Extension.subjectAlternativeName, false, GeneralNames(sans.toTypedArray()))
        val signer = JcaContentSignerBuilder("SHA256withRSA").build(kp.private)
        val cert = JcaX509CertificateConverter().getCertificate(builder.build(signer))

        return KeyStore.getInstance("PKCS12").also { ks ->
            ks.load(null, PWD)
            ks.setKeyEntry(ALIAS, kp.private, PWD, arrayOf(cert))
            f.outputStream().use { ks.store(it, PWD) }
        }
    }

    private fun lanIp(): String? = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it is Inet4Address }
            ?.hostAddress
    } catch (e: Exception) {
        null
    }
}
