package com.stdbridge

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Сервис сенсорного управления. Только реальные жесты через GestureDescription.
 * Никаких действий без включённого пользователем AccessibilityService,
 * взведённого флага armed и соблюдения лимитов.
 */
class TouchService : AccessibilityService() {

    override fun onServiceConnected() {
        TouchController.service = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }

    override fun onInterrupt() { }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (TouchController.service === this) TouchController.service = null
        TouchController.setArmed(this, false)
        return super.onUnbind(intent)
    }
}

data class TouchResult(val id: String, val ok: Boolean, val error: String = "", val ms: Long = 0)

fun TouchResult.toJson(): String =
    JSONObject().put("type", "result").put("id", id).put("ok", ok)
        .put("error", error).put("ms", ms).toString()

object TouchController {
    @Volatile var service: TouchService? = null
    @Volatile var armed: Boolean = false

    private val busy = AtomicBoolean(false)
    private var lastAt = 0L
    private var winStart = 0L
    private var winCount = 0

    const val MIN_INTERVAL_MS = 400L
    const val MAX_PER_MIN = 40
    const val MAX_DURATION_MS = 2000L
    const val GESTURE_TIMEOUT_MS = 3000L

    fun setArmed(ctx: Context, on: Boolean) {
        armed = on
        ctx.getSharedPreferences("bridge", MODE_PRIVATE).edit().putBoolean("touchArmed", on).apply()
        if (!on) busy.set(false)
    }

    fun loadArmed(ctx: Context) {
        armed = ctx.getSharedPreferences("bridge", MODE_PRIVATE).getBoolean("touchArmed", false)
    }

    /** Нормализация 0..1 → пиксели текущего экрана с учётом ориентации. */
    fun toPixels(svc: TouchService, nx: Double, ny: Double): Pair<Float, Float> {
        val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val sw: Int
        val sh: Int
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            sw = b.width()
            sh = b.height()
        } else {
            @Suppress("DEPRECATION")
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            sw = m.widthPixels
            sh = m.heightPixels
        }
        val cx = nx.coerceIn(0.0, 1.0).toFloat() * sw
        val cy = ny.coerceIn(0.0, 1.0).toFloat() * sh
        return Pair(cx, cy)
    }

    fun screenInfo(svc: TouchService): JSONObject {
        val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val sw: Int
        val sh: Int
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            sw = b.width()
            sh = b.height()
        } else {
            @Suppress("DEPRECATION")
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            sw = m.widthPixels
            sh = m.heightPixels
        }
        return JSONObject()
            .put("screenW", sw).put("screenH", sh)
            .put("orientation", if (sw >= sh) "landscape" else "portrait")
    }

    fun handle(svc: TouchService, o: JSONObject): TouchResult {
        val id = o.optString("id", "noid")
        val t0 = System.currentTimeMillis()
        if (!armed) return TouchResult(id, false, "disarmed")
        val s = service ?: return TouchResult(id, false, "no_service")
        if (s != svc) return TouchResult(id, false, "no_service")
        if (!busy.compareAndSet(false, true)) return TouchResult(id, false, "busy")
        try {
            val now = System.currentTimeMillis()
            if (now - lastAt < MIN_INTERVAL_MS) return TouchResult(id, false, "rate")
            if (now - winStart > 60_000) { winStart = now; winCount = 0 }
            if (winCount >= MAX_PER_MIN) return TouchResult(id, false, "rate_min")
            lastAt = now
            winCount++

            val action = o.optString("action", "tap")
            val dur = o.optLong("durationMs", 80).coerceIn(1, MAX_DURATION_MS)
            val (x1, y1) = toPixels(s, o.optDouble("x", -1.0), o.optDouble("y", -1.0))
            if (o.optDouble("x", -1.0) < 0 || o.optDouble("y", -1.0) < 0) {
                return TouchResult(id, false, "bad_coords")
            }
            val path = Path().apply { moveTo(x1, y1) }
            if (action == "drag") {
                val (x2, y2) = toPixels(s, o.optDouble("x2", -1.0), o.optDouble("y2", -1.0))
                if (o.optDouble("x2", -1.0) < 0 || o.optDouble("y2", -1.0) < 0) {
                    return TouchResult(id, false, "bad_coords")
                }
                path.lineTo(x2, y2)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0, dur)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()

            // Синхронное ожидание колбэка — вызывающий поток WsServer, не UI.
            val lock = Object()
            var done: TouchResult? = null
            var watchdog: Runnable? = null
            val main = Handler(Looper.getMainLooper())
            watchdog = Runnable {
                synchronized(lock) {
                    if (done == null) {
                        done = TouchResult(id, false, "gesture_timeout", System.currentTimeMillis() - t0)
                        lock.notifyAll()
                    }
                }
            }
            main.postDelayed(watchdog, GESTURE_TIMEOUT_MS)
            val dispatched = s.dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    synchronized(lock) {
                        if (done == null) {
                            main.removeCallbacks(watchdog)
                            done = TouchResult(id, true, "", System.currentTimeMillis() - t0)
                            lock.notifyAll()
                        }
                    }
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    synchronized(lock) {
                        if (done == null) {
                            main.removeCallbacks(watchdog)
                            done = TouchResult(id, false, "gesture_cancelled", System.currentTimeMillis() - t0)
                            lock.notifyAll()
                        }
                    }
                }
            }, null)
            if (!dispatched) {
                main.removeCallbacks(watchdog)
                return TouchResult(id, false, "dispatch_rejected", System.currentTimeMillis() - t0)
            }
            synchronized(lock) {
                while (done == null) (lock as Object).wait(500)
                return done!!
            }
        } catch (e: Exception) {
            return TouchResult(id, false, "exception", System.currentTimeMillis() - t0)
        } finally {
            busy.set(false)
        }
    }
}

private const val MODE_PRIVATE = Context.MODE_PRIVATE
