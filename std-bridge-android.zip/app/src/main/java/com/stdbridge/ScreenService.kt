package com.stdbridge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

/**
 * Foreground-сервис: VirtualDisplay 720p → ImageReader → JPEG → WsServer.broadcast.
 * Никакого управления игрой: только захват и передача изображения.
 */
class ScreenService : android.app.Service() {

    companion object {
        const val ACTION_START = "com.stdbridge.START"
        const val ACTION_STOP = "com.stdbridge.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val PORT = 8443
        private const val CHANNEL = "bridge"
        private const val NOTIF_ID = 41

        @Volatile
        var isRunning = false
            private set
    }

    private var projection: MediaProjection? = null
    private var display: android.hardware.display.VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var server: WsServer? = null
    private var worker: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var lastSend = 0L
    private var quality = 55
    private var fps = 12

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                shutdown()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val prefs = getSharedPreferences("bridge", MODE_PRIVATE)
                quality = prefs.getInt("quality", 55)
                fps = prefs.getInt("fps", 12)
                val rc = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_DATA)
                }
                if (data == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startCapture(rc, data)
                return START_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        if (isRunning) return
        startForegroundNotif()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(resultCode, data)

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        // Целевой кадр 720p по длинной стороне — экономия трафика без потери читаемости HUD.
        val scale = 720f / maxOf(metrics.widthPixels, metrics.heightPixels).coerceAtLeast(1)
        val w = ((metrics.widthPixels * scale).toInt() / 2 * 2).coerceAtLeast(320)
        val h = ((metrics.heightPixels * scale).toInt() / 2 * 2).coerceAtLeast(320)

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "STDBridge", w, h, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null
        )

        val token = getSharedPreferences("bridge", MODE_PRIVATE).getString("token", "") ?: ""
        val ctx = CertUtil.getOrCreateSSLContext(filesDir)
        server = WsServer(PORT, token, ctx, w, h, fps)
        TouchController.loadArmed(this)
        server!!.onText = { msg, conn -> handleCommand(msg, conn) }
        server!!.start()

        worker = HandlerThread("frames").also { it.start() }
        workerHandler = Handler(worker!!.looper)
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = System.currentTimeMillis()
                if (now - lastSend < 1000L / fps) return@setOnImageAvailableListener
                lastSend = now
                workerHandler?.post { encodeAndSend(img) } ?: run { img.close() }
            } catch (e: Exception) {
                try { img.close() } catch (_: Exception) { }
            }
        }, workerHandler)

        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { shutdown(); stopSelf() }
        }, workerHandler)

        isRunning = true
    }

    private fun encodeAndSend(img: android.media.Image) {
        try {
            val plane = img.planes[0]
            val buf: ByteBuffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * img.width
            val bmpW = img.width + rowPadding / pixelStride
            val bmp = Bitmap.createBitmap(bmpW, img.height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(buf)
            val out = ByteArrayOutputStream(64 * 1024)
            bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
            bmp.recycle()
            server?.broadcastFrame(out.toByteArray())
        } catch (e: Exception) {
            // Пропускаем битый кадр — поток продолжается.
        } finally {
            try { img.close() } catch (_: Exception) { }
        }
    }

    /** Команды управления из браузера: arm / touch / info / stopAll. */
    private fun handleCommand(msg: String, conn: org.java_websocket.WebSocket) {
        try {
            val o = org.json.JSONObject(msg)
            when (o.optString("type")) {
                "arm" -> {
                    val on = o.optBoolean("on", false)
                    TouchController.setArmed(this, on)
                    conn.send(org.json.JSONObject().put("type", "armed").put("on", on).toString())
                }
                "touch" -> {
                    val svc = TouchController.service
                    val res = if (svc == null) {
                        TouchResult(o.optString("id", "noid"), false, "no_service")
                    } else {
                        TouchController.handle(svc, o)
                    }
                    try { conn.send(res.toJson()) } catch (_: Exception) { }
                }
                "info" -> {
                    val svc = TouchController.service
                    val info = org.json.JSONObject()
                        .put("type", "info")
                        .put("touchService", svc != null)
                        .put("armed", TouchController.armed)
                    if (svc != null) {
                        val s = TouchController.screenInfo(svc)
                        info.put("screenW", s.getInt("screenW"))
                            .put("screenH", s.getInt("screenH"))
                            .put("orientation", s.getString("orientation"))
                    }
                    conn.send(info.toString())
                }
                "stopAll" -> {
                    TouchController.setArmed(this, false)
                    conn.send(org.json.JSONObject().put("type", "armed").put("on", false).toString())
                }
            }
        } catch (e: Exception) {
            try {
                conn.send(org.json.JSONObject().put("type", "result")
                    .put("id", "unknown").put("ok", false).put("error", "bad_json").toString())
            } catch (_: Exception) { }
        }
    }

    private fun startForegroundNotif() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "STD Bridge", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("STD Bridge")
            .setContentText("Трансляция экрана идёт")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun shutdown() {
        isRunning = false
        try { display?.release() } catch (_: Exception) { }
        try { reader?.close() } catch (_: Exception) { }
        try { projection?.stop() } catch (_: Exception) { }
        try { server?.stop(1000) } catch (_: Exception) { }
        try { worker?.quitSafely() } catch (_: Exception) { }
        display = null; reader = null; projection = null; server = null; worker = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}
