package com.stdbridge

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Экран TEST TOUCH: большая тестовая кнопка со счётчиком + большая кнопка STOP.
 * ИИ находит кнопку на видеопотоке, нажимает один раз, проверяет счётчик.
 */
class TestTouchActivity : AppCompatActivity() {

    private var count = 0
    private lateinit var tvCount: TextView
    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }

        tvStatus = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
        }
        tvCount = TextView(this).apply {
            textSize = 22f
            gravity = Gravity.CENTER
        }
        val btnTest = Button(this).apply {
            text = "НАЖМИ МЕНЯ"
            textSize = 26f
            setBackgroundColor(Color.parseColor("#D62598")) // фирменный пурпурный — легко найти в кадре
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 420
            ).apply { topMargin = 32 }
            setOnClickListener {
                count++
                tvCount.text = "Нажатий: $count"
            }
        }
        val btnStop = Button(this).apply {
            text = "STOP — запретить касания"
            textSize = 22f
            setBackgroundColor(Color.parseColor("#B91C1C"))
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 48 }
            setOnClickListener {
                TouchController.setArmed(this@TestTouchActivity, false)
                Toast.makeText(this@TestTouchActivity, "Касания запрещены", Toast.LENGTH_SHORT).show()
                refresh()
            }
        }

        root.addView(tvStatus)
        root.addView(tvCount)
        root.addView(btnTest)
        root.addView(btnStop)
        setContentView(root)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val svcOn = TouchController.service != null
        tvStatus.text = "Сервис жестов: ${if (svcOn) "ВКЛ" else "ВЫКЛ (включи в Настройках → Спец. возможности)"}\n" +
            "Разрешено касаться: ${if (TouchController.armed) "ДА" else "НЕТ"}"
        tvCount.text = "Нажатий: $count"
    }
}
