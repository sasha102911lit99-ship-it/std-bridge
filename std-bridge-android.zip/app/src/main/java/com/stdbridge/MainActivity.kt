package com.stdbridge

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.text.format.Formatter
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.security.SecureRandom

/**
 * Главный экран: разрешение MediaProjection, параметры, старт/стоп сервиса.
 * Сам захват и сеть живут в ScreenService — Activity только управляет.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvAddr: TextView
    private lateinit var tvToken: TextView
    private lateinit var tvTouch: TextView
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var cbArm: android.widget.CheckBox

    private val prefs by lazy { getSharedPreferences("bridge", MODE_PRIVATE) }

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            if (res.resultCode == Activity.RESULT_OK && res.data != null) {
                startBridge(res.resultCode, res.data!!)
            } else {
                toast("Разрешение на захват экрана отклонено")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvAddr = findViewById(R.id.tvAddr)
        tvToken = findViewById(R.id.tvToken)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        tvTouch = findViewById(R.id.tvTouch)
        cbArm = findViewById(R.id.cbArm)
        val btnA11y: Button = findViewById(R.id.btnA11y)
        val btnTestTouch: Button = findViewById(R.id.btnTestTouch)
        val sbQuality: SeekBar = findViewById(R.id.sbQuality)
        val sbFps: SeekBar = findViewById(R.id.sbFps)

        sbQuality.progress = prefs.getInt("quality", 55) - 30   // SeekBar 0..50 → 30..80
        sbFps.progress = prefs.getInt("fps", 12) - 5            // SeekBar 0..20 → 5..25

        refreshInfo()

        btnStart.setOnClickListener {
            prefs.edit()
                .putInt("quality", 30 + sbQuality.progress)
                .putInt("fps", 5 + sbFps.progress)
                .apply()
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            captureLauncher.launch(mpm.createScreenCaptureIntent())
        }
        btnStop.setOnClickListener { stopBridge() }
        cbArm.setOnCheckedChangeListener { _, on ->
            TouchController.setArmed(this, on)
            refreshTouch()
        }
        btnA11y.setOnClickListener {
            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btnTestTouch.setOnClickListener {
            startActivity(Intent(this, TestTouchActivity::class.java))
        }
        refreshButtons()
    }

    override fun onResume() {
        super.onResume()
        refreshButtons()
        refreshTouch()
    }

    private fun refreshTouch() {
        val svcOn = TouchController.service != null
        tvTouch.text = "Сервис жестов: ${if (svcOn) "ВКЛ" else "ВЫКЛ (нужны Спец. возможности)"}\n" +
            "Касания разрешены: ${if (TouchController.armed) "ДА (одно)" else "НЕТ"}"
        if (cbArm.isChecked != TouchController.armed) {
            cbArm.setOnCheckedChangeListener(null)
            cbArm.isChecked = TouchController.armed
            cbArm.setOnCheckedChangeListener { _, on ->
                TouchController.setArmed(this, on)
                refreshTouch()
            }
        }
    }

    private fun startBridge(resultCode: Int, data: Intent) {
        val intent = Intent(this, ScreenService::class.java).apply {
            action = ScreenService.ACTION_START
            putExtra(ScreenService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenService.EXTRA_DATA, data)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        toast("Трансляция запускается…")
        tvStatus.postDelayed({ refreshButtons(); refreshInfo() }, 800)
    }

    private fun stopBridge() {
        startService(Intent(this, ScreenService::class.java).apply {
            action = ScreenService.ACTION_STOP
        })
        refreshButtons()
    }

    private fun refreshButtons() {
        val running = ScreenService.isRunning
        btnStart.isEnabled = !running
        btnStop.isEnabled = running
        tvStatus.text = if (running) "Статус: идёт трансляция" else "Статус: остановлен"
    }

    private fun refreshInfo() {
        @Suppress("DEPRECATION")
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val ip = Formatter.formatIpAddress(wifi.connectionInfo.ipAddress)
        tvAddr.text = "Адрес: wss://$ip:8443/  (USB: adb forward tcp:8443 tcp:8443 → wss://127.0.0.1:8443/)"
        tvToken.text = "Токен: ${getOrCreateToken()}"
    }

    private fun getOrCreateToken(): String {
        var t = prefs.getString("token", null)
        if (t.isNullOrBlank()) {
            val bytes = ByteArray(6)
            SecureRandom().nextBytes(bytes)
            t = bytes.joinToString("") { "%02x".format(it) }
            prefs.edit().putString("token", t).apply()
        }
        return t!!
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
